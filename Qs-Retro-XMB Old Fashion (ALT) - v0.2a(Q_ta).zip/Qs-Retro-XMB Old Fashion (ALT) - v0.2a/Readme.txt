- This file contains only the difference of theme changes.
Overwrite the official resource file with the this difference files,
apply the theme.
*Apply after back up the existing resource file, recommend.

After applying the theme, be sure to run below batch file once the 
first time.

/Resources/Qs_tool/Qs_frogtool_listup.bat

*"PCE" and "MULTICORE" folders will be created under the SD card.

- This theme is different from others in that it is set to refer to the 
"PCE" and "MULTICORE" folders.

Other tools, including tadpole and frogtool, do not support these folders.
(* As of September 2024)
In addition, the order of the game system categories has been customized, 
so to update the list after adding a game (rebuild the game list), 
do not use other tools including tadpole and frogtool, but use the 
"Qs_tool" batch file instead.

/Resources/Qs_tool/Qs_frogtool_listup.bat

*The usage (arguments to be given) is the same as frogtool.

- Four shortcuts was delete from the main menu on each system.
(Due to layout. )
By default, the cursor for shortcuts was in "stardust cursor" mode, 
which makes it hard to see the cursor movement in "User ROMS & Settings". 
To switch to "regular cursor" mode, run below batch file.

/Resources/Qs_tool/Qs_switch_cursor.bat

*If run batch file again, cursor will revert to stardust cursor mode.

- Other points to note:
Sound files (nyquest.gdb, swapfile.sys, mfsvr.nkf, oldversion.kbe etc) 
will be overwritten too. Apply after back up the existing resource file, 
recommend.

Since the game menu resources have been changed, 
if rebuild gamelist, 
Please use "Qs_tool" batch file instead of using tadpole / frogtool.
*If an error occurs during list reconstruction processing using a 
batch file, please contact @Q_ta with Discord.

----------------------------------------------------------------------
*The above batch file automates the troublesome movement of game below.
if rebuild gamelist with frogtool, place the game in the below folder.

"MD"  folder: Place GBA/GB/COLOR games.
"GB"  folder: Place PC Engine games.
"GBC" folder: Place SEGA games. (MD/GG/SMS)
"GBA" folder: Place games other than the above categories.
*Other above, it is OK to put the game to same category name folder.

After rebuilding the list, place the game in the folder below.
"MD"  folder: Place SEGA games. (MD/GG/SMS)
"PCE" folder: Place PC Engine games.
"GBA" folder: Place GBA/GB/COLOR games.
"MULTICORE" folder: Place games other than the above categories.
*Other above, it is OK to put the game to same category name folder.
