- This file contains only the difference between theme changes.
Overwrite the official resource file with the current differential resource file
and apply the theme.

- In case you want to change the category of the game system,
that have prepared resource files for different patterns.
Please replace the resources as appropriate.
(For other patterns, please refer to the "Screenshot" folder)
Also change the Foldername.ini folder and use frogtool etc.
You can change the category by rebuilding the list.

- Four shortcuts are delete from the main menu on each system.
(Due to layout)

- Known phenomenon:
Once you enter the game list and select it by moving the cursor,
Then press the A button on each system main menu to
The last game selected in the game list will be launched.

- Other points to note:
xfgle.hgp and swapfile.sys will be overwritten.
Apply after back up the existing resource file, recommend.
