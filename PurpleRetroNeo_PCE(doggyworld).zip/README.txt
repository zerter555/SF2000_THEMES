Credit to Victorus who created the original theme.. this is a modification from his.

https://github.com/vectorus/PurpleRetroNeo_SF2000